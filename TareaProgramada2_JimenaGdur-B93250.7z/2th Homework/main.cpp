#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    cout << "Press the enter key to continue ...";
    cin.get();
    return EXIT_SUCCESS;
}
