#include "GeneticAlgorithm.h"

GeneticAlgorithm::GeneticAlgorithm(int populationSize,float elitismRatio,float mutationRatio,float sporadicRatio)
{
    
}
    
GeneticAlgorithm::~GeneticAlgorithm()
{
    
}

unsigned int GeneticAlgorithm::getEpoch()
{
    return 0;
}

void GeneticAlgorithm::reset(int populationSize,float elitismRatio,float mutationRatio,float sporadicRatio)
{
    
}
